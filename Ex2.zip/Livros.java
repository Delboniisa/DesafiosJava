public class Livros {
    
    String Nome;
    String Titulo;
    int Ano = 0;


}
