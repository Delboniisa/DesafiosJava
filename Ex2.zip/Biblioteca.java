import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class Biblioteca {
    
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner(System.in);

        List <Livros> estante = new ArrayList<>();

        System.out.println("--Bem Vindo(a) a Biblioteca!--");

        System.out.println("Deseja adicionar informações de quantos livros: ");
        int size = leitor.nextInt();

        System.out.println("Insira as informações dos livros: ");

        for(int i=0; i<size; i++){

            System.out.println("Nome do Livro:");
            String nome = leitor.nextLine();
    
            System.out.println("Nome do Autor: ");
            String titulo = leitor.nextLine();
    
            System.out.println("Ano de publicação: ");
            int ano = leitor.nextInt();
            
        }


    }
}
